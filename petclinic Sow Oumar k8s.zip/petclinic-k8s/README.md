# Spring PetClinic sur Kubernetes (Local)

## Prérequis
- Docker
- Minikube
- kubectl
- VS Code

## Déploiement
minikube start
eval $(minikube docker-env)
docker build -t petclinic:1.0 app/
kubectl apply -f k8s/

## Accès
minikube service petclinic-service
